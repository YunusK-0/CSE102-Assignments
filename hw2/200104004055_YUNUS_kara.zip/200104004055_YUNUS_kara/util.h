#ifndef _UTIL_H_
#define _UTIL_H_

#define CLOSE_ENOUGH 0.001

typedef enum
{
    walking,car,ship,airplane,train}
how;


/* Example decision tree - see the HW2 description */
int dt0(int t, double p, double h, int s, int w);

char dt1a(double pl, double pw);
char dt1b(double pl, double pw);

double dt2a(double x1, double x2, double x3, int x4, int x5);
double dt2b(double x1, double x2, double x3, int x4, int x5);

/* Write the prototype of the functions implementing the decision trees for the third problem */
char	dt3a(float distance, float time, int logic, how arac_1, how arac_2);
char	dt3b(float distance, float time, int logic, how arac_1, how arac_2);

#endif /* _UTIL_H_ */