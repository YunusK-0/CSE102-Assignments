#include <stdio.h>
#include "util.h"

/* Example decision tree - see the HW2 description */
int dt0(int t, double p, double h, int s, int w) {
    int r = 0;
    if (t>35 && w!=3) r = 1;
    else if (t<=35 && s==0) r = 1;
    return r;
}

char    dt1a(double pl, double pw)
{
    if(pl < 2.45)
        return 's';
    else
    {
        if(pw < 1.75)
        {
            if(pl <4.95)
            {
                if(pw<1.65)
                    return 'v';
                else
                    return 'g';
            }
            else
                return 'g';
        }
        else
            return 'g';
    }
}

char    dt1b(double pl, double pw)
{
    if(pl<2.25)
        return 's';
    else
    {
        if(pw<1.69)
        {
            if(pl<4.85)
                return 'v';
            else
                return 'g';
        }
        else
            return 'g';
    }
}

double dt2a(double x1, double x2, double x3, int x4, int x5)
{
    if(x1 < 31.5)
    {
        if(x2 > -2.5)
            return 5.0;
        else
        {
            if(x2 - x1 <= 0.2)
                return 1.1;
            else
                return -8;
        }
    }
    else
    {
        if(x3 <= 2 && x3 >= -1)
            return 1.4;
        else
        {
            if(x4 == 1 && x5==1)
                return -2.23;
            else
                return 11.0;
        }
    }
}

double dt2b(double x1, double x2, double x3, int x4, int x5)
{
    if(x1> 12 && x1<22)
    {
        if( x3 > 5/3)
            return -2.0;
        else
        {
            if(x3-x1 <= 0.2)
                return 1.01;
            else
                return -8;
        }
    }
    else
    {
        if(x4 == 1 && x5==1)
            return -1;
        else
        {
            if( x2>= -1 && x2<=2)
                return -1/7;
            else
                return 1.414213/3;
        }
    }
} 

char dt3a(float distance, float time, int logic, how arac_1, how arac_2)
{
    if(distance<1000)
    {
        if(time>48)
        {
            if(arac_1 > 0)
            {
                return 's';
            }
            else 
                return 'f';
        }
        else
            if(arac_2> 3)
                return 's';
            else 
                return 'f';
    }
    else
    {
        if(time <48)
        {
            if(logic && logic == 1)
            {   
                if(arac_1>=2&&arac_1<=4)
                    return 's';
                else
                    return 'f';
            }
            else
            {
                if(arac_2>=arac_1)
                    return 'f';
                else
                    return 's';
            }

        }
        else
        {
            if(logic && logic == 1)
            {
                if(arac_2 == 1)
                    return 'f';
                else
                    return 's';
            }
            else
            {
                if(arac_1 > arac_2)
                    return 's';
                else
                    return 'f';
            }
        }
    }
}

char    dt3b(float distance, float time, int logic, how arac_1, how arac_2)
{
    if(logic && logic == 1)
    {
        if(time >24)
        {
            if(distance <500)
                return 's';
            else
            {
                if(arac_1>1)
                    return 's';
                else
                    return 'f';
            }

        }
        else
        {
            if(distance>=100)
                return 'f';
            else
            {
                if(arac_2> arac_1)
                {
                    if(arac_2 >2)
                        return 's';
                    else
                        return 'f';
                }
                else
                {
                    if(arac_1 >2)
                        return 's';
                    else
                        return 'f';
                }

            }
        }
    }

    else
    {
        if(arac_1 <3 && arac_2<3)
            return 'f';
        else
        {
            if(distance > 1200)
            {
                if(time > 10)
                    return's';
                else
                    return 'f';
            }
            if(time > 20)
                return 's';
            else
                return 'f';
        }
    }

}



/* Provide your implementations for all the requested functions here */