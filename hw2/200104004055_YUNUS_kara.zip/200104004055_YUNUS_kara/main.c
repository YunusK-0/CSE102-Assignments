#include <stdio.h>
#include <stdlib.h>
#include "util.h"


int main() {
    float   distance;    // for tree3
    float   time;   // for tree3
    int logic;  // for tree3
    how arac_1; //for tree typedef value
    how arac_2;// for tree3 typedef value
    char res_1; // for tree3 it was used to get a value from function
    char res_2;// for tree3 was used to get a value from function
    int arac_int1; // for tree3 in order to get a value from the user. and use it with typedef one
    int arac_int2; // for tree 3 in order to get value from user 
    int selection;
    char result1; // it was used for the first problem to get a value from function.
    char result2; // it was used for the first problem to get a value from function
    double son1, son2;// it was used for the second problem to get a value from function.
    double x1,x2,x3; // it was used for the second problem to get a value from function.
    int x4,x5;
    double sl,sw; //for problem 1
    double pl,pw; // for problem1
    int tempature;
    int pressure;
    int humidity;
    int sunny;
    int week;
    printf("please select one of them\npress0, for the example\npress 1, for first problem\npress 2,for second problem\npress 3, for third problem\n");
    scanf("%d",&selection);

    if(selection == 1)
    {
        printf("give PL\n");
        scanf("%lf",&pl);
        printf("give PW\n");
        scanf("%lf",&pw);
        printf("give SL\n");
        scanf("%lf", &sl);
        printf("give SW\n");
        scanf("%lf", &sw);
        result1 = dt1a(pl,pw);
        result2 = dt1b(pl,pw);
        if(result1==result2)
        {
            if(result1=='v') // it is represents versicolor
                printf("Versicolor\n");
            else if(result1 == 'g') // it is represents virginica
                printf("Virginica\n");
            else
                printf("Setosa");
        }
        else
        {
            if(result1=='s')
            {
                if(result1=='s')
                    printf("Three 1- Setosa. Three 2- Virginica");
                else
                    printf("Three 1- Setosa. Three 2- Versicolor");
            }
            else if(result1 == 'g')
            {
                if(result2 == 's')
                    printf("Three 1- Virginica. Three 2- Setosa");
                else
                    printf("Three 1- Virginica. Three 2- Versicolor");
            }
            else
            {
                if(result2 == 'g')
                    printf("Three 1- Versicolor. Three 2- Virginica");
                else
                    printf("Three 1- Versicolor. Three 2- Setosa");
            }
        }
    }
    else if(selection ==2)
    {
        printf("give the value of x1\n");
        scanf("%lf",&x1);
        printf("give the value of x2\n");
        scanf("%lf",&x2);
        printf("give the value of x3\n");
        scanf("%lf",&x3);
        printf("give binary value\n");
        scanf("%d",&x4);
        if(x4 !=1 && x4 != 0)// forcing user to get a binary number which is 1 or 0.
        {
            for(;x4 != 0 && x4 !=1;)
            {
                printf("give 1 or 0\n");
                scanf("%1d",&x4);
            }
        }
        printf("give another binary value\n");
        scanf("%d",&x5);
        if(x5 !=1 || x5 != 0) // forcing user to get a binary number which is 1 or 0.
        {
            for(;x5 != 0 && x5 !=1;)
            {
                printf("give 1 or 0\n");
                scanf("%1d",&x5);
            }
        }
        son1 = dt2a(x1,x2,x3,x4,x5);
        son2 = dt2b(x1,x2,x3,x4,x5);
        if(son1 == son2) // checking the same or not
        {
            printf("result %lf\n ",(son1+son2)/2);
        } 
        else if((son1 > son2) && son1- son2 <= CLOSE_ENOUGH) // if they are diffrent, check for the CLOSE_Enough value.
        {
            printf("result %lf\n", (son1+son2)/2);
        }
        else if((son1 < son2) && son2- son1 <= CLOSE_ENOUGH)
        {
            printf("result %lf\n", (son1+son2)/2);
        }
        else // if it is diffrent it prints both of them
            printf("tree 1- %lf and tree 2- %lf",son1,son2);
    }
    else if (selection ==3)
    {
        printf ("write the distance that you want to go\n");
        scanf("%f",&distance);
        printf("write how many hours that you have\n");
        scanf("%f",&time);
        printf("is it important (if yes print 1) (otherwise print 0) ");
        scanf("%d",&logic);
        printf("Select two of them\n(0)walking\n(1)car\n(2)ship\n(3)airplane\n(4)train\n");
        scanf("%d",&arac_int1);
        scanf("%d",&arac_int2);
        arac_1 = arac_int1 %5;
        arac_2 = arac_int2 %5;
        if(logic !=1 || logic != 0) // forcing user to get a binary number which is 1 or 0.
        {
            for(;logic != 0 && logic !=1;)
            {
                printf("give 1 or 0\n");
                scanf("%1d",&logic);
            }
        }
        if(time <0) // forcing user to get a positive time because it can't be negative .
        {
            for(;time<0;)
            {
                printf("give pozitif time \n");
                scanf("%f",&time);
            }
        }
        if(distance <0) // it can't be negative, so force it 
        {
            for(;distance<0;)
            {
                printf("give positive distance\n");
                scanf("%f",&distance);
            }
        }
      res_1 = dt3a(distance, time,logic, arac_1, arac_2); // getting value from function.
      printf("%c\n",res_1);
      res_2 = dt3b(distance,time,logic,arac_1,arac_2); // getting value from function.
      printf("%c\n",res_2);
      if(res_1 == res_2 && res_2 =='s') // checking they are same or not.
        printf("you will reach there successfuly\n");
      else if(res_1==res_2 && res_2 =='f')
        printf("you will be failed\n");
      else if(res_1 != res_2)
        printf("%%50 you will be succesful and %%50 you will be failed\n"); 
    }
    else if(selection == 0)
    {
        printf("give the tempature");
        scanf(" %d",&tempature);
        printf("give the pressure");
        scanf(" %d",&pressure);
        printf("give the humidity");
        scanf(" %d",&humidity);
        printf("give the sunny or not (if it is sunny press 1) (else press 0 )");
        scanf(" %d",&sunny);
        printf("monday(1)\n tuesday(2)\n(3)wednesday\n(4)thursday\n(5)friday\n(6)saturday\n(7)sunday\n");
        scanf(" %d",&week);        
        int problem_1;
        problem_1 = dt0(tempature,pressure,humidity,sunny,week);
        if(problem_1 == 1)
            printf("turn on \n");
        else
            printf("turn off \n");
    }

    return 0;
}
